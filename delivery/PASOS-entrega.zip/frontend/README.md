# PASOS classroom setup

## Package and privacy

This public package contains no private OAuth application configuration and no Google authorization. The Google token table starts empty. Obtain the OAuth configuration privately, copy backend/config/google.local.php.example to backend/config/google.local.php, and configure the real values locally. The lawyer must connect Google before using Calendar/Meet. Never commit the local configuration or tokens.

Google Testing refresh-token lifetime is normally seven days from the original consent, not from this export or SQL import. Local presence and timestamps do not prove the remaining lifetime, remote validity, or availability tomorrow. Re-exporting does not restart that clock. In the separate private delivery, the copied access token was locally expired at export and will need a refresh during authorized online use; reconnecting Google may be necessary. No Google validity was proven and no refresh was performed.

## Safe local setup

1. Extract the ZIP outside Apache's public document root, for example into a private folder in your personal Downloads. Keep the private ZIP and root `pasos.sql` outside `htdocs`, Git, and every public web directory. Private SQL contains Google account authorization, including access/refresh tokens, not just schema; never publish it or the private ZIP.
2. Start Apache and MySQL. In phpMyAdmin, import root `pasos.sql` directly from that private folder into a fresh demo setup. It creates/selects database `pasos` with three tables and three demo identity seeds. Never import over a working database. Local connection defaults are MySQL on port 3306, user root, empty password; adjust your local connection settings only if needed.
3. Create only the Apache project mapping folder `C:\xampp\htdocs\proyecto-intefacesweb-develop` (Linux XAMPP: `/opt/lampp/htdocs/proyecto-intefacesweb-develop`). Copy only `backend/` into its `backend/` subdirectory. The private package includes `backend/config/google.local.php`; the public package includes only its example and requires the real OAuth configuration separately. Do not copy SQL, either ZIP, or `frontend/` into the Apache mapping. This keeps the registered callback at `http://localhost/proyecto-intefacesweb-develop/backend/api/google_callback.php` unchanged.
4. Keep `frontend/` outside `htdocs`. With Node.js 22.12+ installed, run `npm install` and `npm run dev` from its folder, then open `http://localhost:5174/`. Apache must serve `http://localhost/proyecto-intefacesweb-develop/backend/` on port 80 while Vite runs separately. The existing proxy works with this mapping; do not open `index.html` directly.

The backend is not fully portable outside this Apache mapping. No portable PHP launcher or callback change is included or approved. Frontend placement outside `htdocs` does not remove the backend's Apache prerequisite.

The public repository ZIP is token-free, and source SQL/schema remains unchanged. Keep private SQL and ZIP copies private even after import; they are not files to serve over HTTP.

## Identities and demonstration limits

The lawyer seed is bound to the confirmed Firebase UID in the included Firebase project. Use the existing account credentials supplied privately; no live passwords are included. The ordinary client placeholder binds only after verified Firebase login. The administrator placeholder remains blocked until a trusted administrator Firebase UID is set manually; do not invent a UID or promote a client.

The client Gmail account receives Calendar invitations; it does not need to authorize the lawyer's Calendar OAuth application. Only the lawyer owns this integration's Google authorization.

No Google/Firebase remote checks, clean Windows installation, browser sign-in, event creation, or Meet demonstration were performed for this export. A real demonstration can require internet access and fresh Google consent. The callback and development-server mapping are unchanged.
