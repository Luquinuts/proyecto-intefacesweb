# Repository export notice — PASOS

This repository-safe export contains **no OAuth credentials**. Its runtime files
match the current repository; the README is tailored for this export and only the
lawyer UID in `database/pasos.sql` uses the trusted, user-provided Firebase binding.
The original private delivery is unchanged, remains outside Git, and is not included.

The lawyer UID is preconfigured only for the provided Firebase project. No lawyer
UID replacement is required for that project. Normal client linking is unchanged.
The optional administrator is unbound and safely blocked until an administrator
manually supplies a trusted Firebase-console UID before a fresh import. Do not
rerun the seed to change existing identities. Account passwords are provided
separately; no account password, login token or live database dump is included.

## Start locally

1. Extract `proyecto-intefacesweb-develop/` directly under XAMPP's `htdocs`.
2. Start Apache and MySQL. PHP needs mysqli and cURL. Import
   `database/pasos.sql` through phpMyAdmin for a **fresh database only**; it creates
   the `pasos` schema. No additional migration is needed for a fresh installation.
   Preserve existing databases; the three migration files are for older schemas.
3. With Node.js 22.12+ and npm, run inside `frontend/`:

   ```bash
   npm install
   npm run dev
   ```

4. Open `http://localhost:5174/`. Keep the folder name, hostname and strict port;
   Vite proxies PHP requests to Apache at `http://localhost/proyecto-intefacesweb-develop`.
   Stop an older frontend instance if the port is busy. Never serve PHP source
   through a static server or Vite preview. Use HTTPS outside localhost.

Public Firebase configuration is included in `frontend/config.js` and
`backend/config/firebase.php`; valid Firebase accounts and the database are still
required. Source connection defaults in `backend/config/conexion.php` target local
XAMPP. Custom installations can set `PASOS_DB_HOST`, `PASOS_DB_USER`,
`PASOS_DB_PASSWORD`, `PASOS_DB_NAME` and `PASOS_DB_PORT` privately in Apache's
environment. Do not commit private configuration.

## Google Calendar/Meet requires private configuration

Copy `backend/config/google.local.php.example` to
`backend/config/google.local.php` and obtain the real OAuth configuration privately.
**Never commit that local file.** The example contains placeholders only. The core
application can run with the included Firebase project configuration and valid
accounts, but Calendar/Meet authorization and scheduling need this additional
private setup. The Cloud owner must enable the required APIs and allow the
connecting Google account while OAuth is in testing mode. Connect Google Calendar
as the professional and complete browser consent.

The registered callback must be exactly
`http://localhost/proyecto-intefacesweb-develop/backend/api/google_callback.php`;
the backend returns to `http://localhost:5174/`. `PASOS_FRONTEND_URL` supports a
custom Apache-configured frontend origin. Do not publish credentials or account
passwords in source, logs, screenshots or shared database exports.

The preserved [setup reference](docs/google-calendar-meet-setup.md) describes the
older **private** classroom bundle. This repository export notice overrides every
statement there that credentials are included, that the whole ZIP must remain
private, or that the supplied lawyer UID still needs binding. Only the optional
administrator needs manual trusted binding for this supplied Firebase project.
Use that reference's browser checklist and operational details, not its private
bundle distribution instructions. The local OAuth file must always remain private.

## Offline checks and verification limits

After installing dependencies, run from the extracted project root:

```bash
php -d zend.assertions=1 -d assert.exception=1 tests/request-guard.php
php -d zend.assertions=1 -d assert.exception=1 tests/consultation-rules.php
php -d zend.assertions=1 -d assert.exception=1 tests/google-calendar-meet.php
php -d zend.assertions=1 -d assert.exception=1 tests/firebase-auth.php
node --experimental-vm-modules tests/frontend-sfc.mjs
npm --prefix frontend run build
```

The concurrency runner requires a separately provisioned disposable test database
and explicit opt-in; never point it at live PASOS data. No application services,
accounts or databases were changed to produce this export. Packaging checks are
not proof of real Google/browser behavior, clean-machine installation, invitation
delivery or the required course video/PDF demonstration. Those remain manual.
