<?php

require_once __DIR__ . '/lib/RequestGuard.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') pasos_require_write();
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['correcto' => false, 'mensaje' => 'Method not allowed.']);
    exit;
}

$_SESSION = array();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['correcto' => true]);
